import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SILab2Test {

    @Test
    void testEveryBranch() {
        // Тест случај 1: Празна листа
        Executable nullListExecutable = () -> SILab2.checkCart(null, 100);
        RuntimeException nullListException = assertThrows(RuntimeException.class, nullListExecutable);
        assertEquals("allItems list can't be null!", nullListException.getMessage());

        // Тест случај 2: Влезен предмет со невалиден карактер во баркод
        List<Item> invalidBarcodeList = new ArrayList<>();
        invalidBarcodeList.add(new Item("item1", "12A45", 100, 0));
        Executable invalidBarcodeExecutable = () -> SILab2.checkCart(invalidBarcodeList, 200);
        RuntimeException invalidBarcodeException = assertThrows(RuntimeException.class, invalidBarcodeExecutable);
        assertEquals("Invalid character in item barcode!", invalidBarcodeException.getMessage());

        // Тест случај 3: Влезен предмет без баркод
        List<Item> noBarcodeList = new ArrayList<>();
        noBarcodeList.add(new Item("item2", null, 100, 0));
        Executable noBarcodeExecutable = () -> SILab2.checkCart(noBarcodeList, 200);
        RuntimeException noBarcodeException = assertThrows(RuntimeException.class, noBarcodeExecutable);
        assertEquals("No barcode!", noBarcodeException.getMessage());

        // Тест случај 4: Влезен предмет со попуст
        List<Item> discountItemList = new ArrayList<>();
        discountItemList.add(new Item("item3", "12345", 100, 0.2f));
        assertTrue(SILab2.checkCart(discountItemList, 20));

        // Тест случај 5: Влезен предмет со цена поголема од 300, попуст и баркод кој започнува со '0'
        List<Item> specialDiscountList = new ArrayList<>();
        specialDiscountList.add(new Item("item4", "012345", 400, 0.5f));
        assertTrue(SILab2.checkCart(specialDiscountList, 170));

        // Тест случај 6: Сите останати случаи
        List<Item> mixedItemsList = new ArrayList<>();
        mixedItemsList.add(new Item("item5", "67890", 200, 0));
        mixedItemsList.add(new Item("item6", "23456", 100, 0.1f));
        assertTrue(SILab2.checkCart(mixedItemsList, 290));
        assertFalse(SILab2.checkCart(mixedItemsList, 189));
    }

    @Test
    void testAdditionalCases() {
        // Тест случај 1: Празна листа на предмети и нула за плаќање
        List<Item> emptyList = new ArrayList<>();
        assertTrue(SILab2.checkCart(emptyList, 0));

        // Тест случај 2: Предмет со празно име
        List<Item> emptyNameList = new ArrayList<>();
        emptyNameList.add(new Item("", "12345", 100, 0));
        assertTrue(SILab2.checkCart(emptyNameList, 100));
        assertEquals("unknown", emptyNameList.get(0).getName());

        // Тест случај 3: Влезен предмет со име кое е null
        List<Item> nullNameList = new ArrayList<>();
        nullNameList.add(new Item(null, "12345", 100, 0));
        assertTrue(SILab2.checkCart(nullNameList, 100));
        assertEquals("unknown", nullNameList.get(0).getName());

        // Тест случај 4: Предмет со валиден баркод но без попуст
        List<Item> validBarcodeNoDiscount = new ArrayList<>();
        validBarcodeNoDiscount.add(new Item("item7", "1234567890", 150, 0));
        assertTrue(SILab2.checkCart(validBarcodeNoDiscount, 150));
    }
}
